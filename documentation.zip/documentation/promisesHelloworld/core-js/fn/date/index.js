require('../../modules/es6.date.now');
require('../../modules/es6.date.to-json');
require('../../modules/es6.date.to-iso-string');
require('../../modules/es6.date.to-string');
require('../../modules/es6.date.to-primitive');
module.exports = require('../../modules/_core').Date;