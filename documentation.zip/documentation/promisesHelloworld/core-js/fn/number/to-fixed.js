require('../../modules/es6.number.to-fixed');
module.exports = require('../../modules/_core').Number.toFixed;