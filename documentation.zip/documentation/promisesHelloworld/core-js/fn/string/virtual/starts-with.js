require('../../../modules/es6.string.starts-with');
module.exports = require('../../../modules/_entry-virtual')('String').startsWith;