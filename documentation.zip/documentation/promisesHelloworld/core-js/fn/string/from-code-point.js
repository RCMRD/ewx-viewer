require('../../modules/es6.string.from-code-point');
module.exports = require('../../modules/_core').String.fromCodePoint;