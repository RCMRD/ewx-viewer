require('../../modules/es6.math.sinh');
module.exports = require('../../modules/_core').Math.sinh;