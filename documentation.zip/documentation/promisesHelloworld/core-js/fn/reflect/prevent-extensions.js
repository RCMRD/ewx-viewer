require('../../modules/es6.reflect.prevent-extensions');
module.exports = require('../../modules/_core').Reflect.preventExtensions;